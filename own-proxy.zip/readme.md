Замените "/Users/macos-username/Desktop/own_proxy" на путь к папке в вашей системе и запустите команду в терминале:

cd /Users/macos-username/Desktop/own_proxy && chmod +x run.sh && ./run.sh